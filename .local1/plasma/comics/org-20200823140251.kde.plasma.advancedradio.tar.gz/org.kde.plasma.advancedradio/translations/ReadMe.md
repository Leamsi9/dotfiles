|  Locale  |  Lines  | % Done|
|----------|---------|-------|
| Template |      34 |       |
| de_DE    |    0/34 |    0% |
| ru_RU    |   33/34 |   97% |
